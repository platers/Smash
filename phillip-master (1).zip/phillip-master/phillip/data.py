short_hop = dict(
  fox = 2,
  ice_climbers = 2,
  kirby = 2,
  samus = 2,
  sheik = 2,
  pichu = 2,
  pikachu = 2,
  
  dr_mario = 3,
  mario = 3,
  luigi = 3,
  falcon = 3,
  ness = 3,
  young_link = 3,
  gnw = 3,
  marth = 3,
  
  peach = 4,
  yoshi = 4,
  dk = 4,
  falco = 4,
  puff = 4,
  mewtwo = 4,
  roy = 4,
  
  ganon = 5,
  zelda = 5,
  link = 5,
  
  bowser = 7
)

