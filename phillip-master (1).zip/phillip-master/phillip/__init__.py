import os
path = os.path.dirname(__file__)
