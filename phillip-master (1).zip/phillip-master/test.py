#!/bin/env python

from phillip import tf_lib

tf_lib.testDiscounts()