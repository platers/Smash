# Running Phillip in Docker

You'll need a linux system with docker installed, as well as a Gamecube controller plugged into port 1 of a Wii U adapter.

1. Set up udev rule (only need to do once on the host machine):

    ./setup.sh

2. Run phillip:

    ./falcon.sh

This should take you to the character select screen.
